package beans;

import java.time.LocalDate;

/**
 *
 * @author Manuel
 */
public class Student {
    
    private final String studentClass;
    private final String lastname;
    private final String firstname;
    private final LocalDate birthdate;

    public Student(String studentClass, String lastname, String firstname, LocalDate birthdate) {
        this.studentClass = studentClass;
        this.lastname = lastname;
        this.firstname = firstname;
        this.birthdate = birthdate;
    }

    public String getStudentClass() {
        return studentClass;
    }

    public String getLastname() {
        return lastname;
    }

    public String getFirstname() {
        return firstname;
    }

    public LocalDate getBirthdate() {
        return birthdate;
    }
    
    public String getFullName()
    {
        return lastname + " " + firstname;
    }
}
